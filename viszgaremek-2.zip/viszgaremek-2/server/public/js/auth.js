document.addEventListener('DOMContentLoaded', () => {
    const navItems = document.getElementById('nav-items');
    const token = localStorage.getItem('token');

    if (token) {
        const user = JSON.parse(atob(token.split('.')[1]));
        navItems.innerHTML = `
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Felkapot.html">Felkapott</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/profil.html">${user.username}</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="naplo.html">Napló</a>
            </li>
            
        `;
    } else {
        navItems.innerHTML = `
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.html">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Felkapot.html">Felkapott</a>
            </li>
        `;
    }
});