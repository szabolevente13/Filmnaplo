
document.addEventListener('DOMContentLoaded', () => {
    fetch('/ranked-films')
        .then(response => response.json())
        .then(data => {
            const filmSection = document.getElementById('film-recommendation-section');

            data.forEach(films => {
                filmSection.innerHTML += `
                    <div class="card h-100 col-12 col-md-4 mb-4">
                        <img class="card-img-top" src="/static/img/pics/${films.pic_url}" alt="StarWars" height="190" width="270">
                        <div class="card-body">
                            <h4>${films.title}</h4>
                            <p>${films.content}<br><strong>${films.genre}</strong></p>
                        </div>
                        
                    </div>`;
            });
        })
        .catch(error => console.log('Hiba a lekérdezésnél', error));
});

document.addEventListener('DOMContentLoaded', () => {
    fetch('/ranked-series')
        .then(response => response.json())
        .then(data => {
            const seriesSection = document.getElementById('series-recommendation-section');

            data.forEach(series => {
                seriesSection.innerHTML += `
                    <div class="card h-100 col-12 col-md-4 mb-4">
                        <img class="card-img-top" src="/static/img/pics/${series.pic_url}" alt="penzrablas" height="190" width="270">
                        <div class="card-body">
                            <h4>${series.title}</h4>
                            <p>${series.content}<br><strong>${series.genre}</strong></p>
                        </div>
                       
                    </div>`;
            });
        })
        .catch(error => console.log('Hiba a lekérdezés során: ', error));
});