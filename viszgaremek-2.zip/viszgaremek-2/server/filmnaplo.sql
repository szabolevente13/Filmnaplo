-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Már 27. 12:24
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `filmnaplo`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `film_diary`
--

CREATE TABLE `film_diary` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `director` varchar(255) NOT NULL,
  `date` varchar(100) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `film_diary`
--

INSERT INTO `film_diary` (`id`, `userId`, `title`, `director`, `date`, `genre`, `rating`) VALUES
(1, 1, 'aSa', 'dadasds', '2025-03-10 16:50:06.653', 'salads', 3),
(2, 1, 'dsadad', 'dasdasd', '2025-03-10 16:50:53.416', 'sdaddas', 3),
(3, 1, 'adsadasd', 'dsadasdas', '2025-03-10 16:52:37.682', 'ad', 5);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `film_likes`
--

CREATE TABLE `film_likes` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `filmId` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `film_likes`
--

INSERT INTO `film_likes` (`id`, `userId`, `filmId`, `created_at`) VALUES
(1, 1, 3, '2025-03-24 19:05:25'),
(2, 1, 2, '2025-03-24 19:10:30');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `film_recommendation`
--

CREATE TABLE `film_recommendation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `genre` varchar(100) NOT NULL,
  `pic_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `film_recommendation`
--

INSERT INTO `film_recommendation` (`id`, `title`, `content`, `genre`, `pic_url`) VALUES
(1, 'Avengers: Endgame', 'Az Avengers: Endgame a Marvel Moziverzum egyik legfontosabb filmje, amely 2019-ben jelent meg, és az előző rész, az Avengers: Infinity War eseményeit folytatja.Thanos, az univerzum legnagyobb fenyegetése, sikeresen végrehajtja tervét, és a Végtelen Kövek segítségével eltörli az élőlények felét. A megmaradt hősök – köztük Vasember, Amerika Kapitány, Thor, Fekete Özvegy, Hulk és Sólyomszem – összefognak, hogy visszafordítsák a katasztrófát.', 'Kaland, Scifi', 'AVEND.jpg'),
(2, 'Star Wars  A Sith-ek bosszúja', 'A saga egyik legsötétebb és legdrámaibb fejezete, amely az előzménytrilógia csúcspontjaként szolgál.A film Anakin Skywalker tragikus átalakulását mutatja be Darth Vaderré, miközben a Galaktikus Köztársaság a Sith-ek ármánykodása miatt a Birodalommá válik.A látványos csaták és érzelmi konfliktusok mellett a történet középpontjában az árulás, a hatalomvágy és a választásaink következményei állnak.Ez a rész fájdalmas.', 'Scifi', 'SW3.jpg'),
(3, 'A remény rabjai', 'A remény rabjai egy szívbemarkoló és felemelő történet az emberi kitartásról és a remény erejéről. A film Andy Dufresne-ről, egy ártatlanul elítélt bankárról szól, aki   két évtizedet tölt egy szigorúan őrzött börtönben. \r\nBarátsága Ellis Reddinggel, egy tapasztalt rabtárssal, és rendíthetetlen hite abban, hogy a szabadság valamiképp elérhető, adja a történet központját.Az erős karakterek, az érzelmes fordulatok és az emlékezetes befejezés teszik  ezt a filmet igazán egy időtálló klasszikussá.', 'Dráma', 'remeny.jpg'),
(4, 'Deadpool és Rozsomák', 'A Deadpool és Rozsomák 2024-ben bemutatott amerikai szuperhősfilm Shawn Levy rendezésében. Gyártója a Marvel Studios és a Maximum Effort, forgalmazója a Walt Disney Studios Motion Pictures.\r\n A Deadpool 2. folytatása, azzal a csavarral, hogy összefonódik a Marvel-moziuniverzummal (MCU), aminek immáron a harmincnegyedik filmje.\r\n  A főbb szerepekben Ryan Reynolds, Hugh Jackman, Emma Corrin, Morena Baccarin, Rob Delaney, Leslie Uggams, Aaron Stanford és Matthew Macfadyen látható.', 'szuperhősfilm,akciófilm', 'deadpesrozsm.jpg'),
(5, 'Nosferatu ', 'A Nosferatu 2024-es amerikai gótikus horrorfilm, amelyet Robert Eggers írt és rendezett. Az 1922-es Nosferatu című némafilm remake-je, amelyet Bram Stoker 1897-es Drakula című regénye ihletett.\r\n A főbb szerepekben Bill Skarsgård, Nicholas Hoult, Lily-Rose Depp, Aaron Taylor-Johnson, Emma Corrin és Willem Dafoe látható. A Nosferatu világpremierje 2024. december 2-án volt Berlinben, december 25-én mutatta be a Focus Features az Egyesült Államokban,  Magyarországon január 2-án jelent meg .', 'vámpírfilm, filmdráma', 'Nosferatu.jpg'),
(6, 'Bad Boys 4', ' A Bad Boys – Mindent vagy többet  2024-ben bemutatott amerikai akció-filmvígjáték, melyet Chris Bremmer forgatókönyvéből Adil El Arbi és Bilall Fallah rendezett. \r\n A Bad Boys – Mindörökké rosszfiúk folytatása, valamint a Bad Boys-filmsorozat negyedik része. Will Smith, Martin Lawrence, és DJ Khaled megismétlik az előző filmből ismert szerepüket, ,Tasha Smith pedig Theresa Burnett szerepét vette át  aki korábban az előző három filmben játszotta a karaktert. Új szereplőként  Melanie Liburd és Tiffany Haddish csatlakozott.', 'akciófilm', 'badboys4.jpg'),
(7, 'Pókember', 'A 2002-es Pókember egy szuperhősfilm, amelyet Sam Raimi rendezett, és a Marvel Comics híres karakterén, Pókemberen alapul. A film a Pókember képregényekben szereplő Peter Parker történetét meséli el, aki egy sugárzás következtében különleges képességekre tesz szert, miután egy radioaktív pók megmarja. A film központjában Peter Parker átváltozása áll: egy átlagos fiatalemberből szuperhőssé válik, miközben próbálja egyensúlyban tartani a személyes életét és hősi küldetését. A film főszereplője Tobey Maguire, aki Peter Parkert/Pókembert alakítja. Mellette szerepel Kirsten Dunst Mary Jane Watson szerepében, Willem Dafoe pedig a film főgonoszát, Norman Osbornt/Green Goblint formálja meg.', 'sci-fi film filmdráma', 'pokember.jpg'),
(8, 'Vissza a jövőbe II', 'A Vissza a jövőbe 2  egy 1989-es amerikai sci-fi kalandfilm, amely Robert Zemeckis rendezésében készült. Ez a film a Vissza a jövőbe (1985) folytatása, és a harmadik részével együtt egy trilógiát alkot. A történet középpontjában ismét Marty McFly (Michael J. Fox) és Dr. Emmett Brown (Christopher Lloyd) áll, akik ismét utaznak az időben, hogy megakadályozzanak egy jövőbeli katasztrófát. A filmben a főszereplők először a jövőbe, 2015-be utaznak, ahol Marty próbálja megakadályozni, hogy családja pénzügyi helyzete elromoljon. A  képeslapokból ismert időutazás egy új, izgalmas irányba terelik a cselekményt. Azonban a dolgok nem mennek simán, és hamarosan vissza kell térniük a múltba.', 'kaland sci-fi ', 'backtothefuture.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `series_likes`
--

CREATE TABLE `series_likes` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `seriesId` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `series_likes`
--

INSERT INTO `series_likes` (`id`, `userId`, `seriesId`, `created_at`) VALUES
(1, 1, 6, '2025-03-24 19:05:29');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `series_recommendation`
--

CREATE TABLE `series_recommendation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `genre` varchar(100) NOT NULL,
  `pic_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `series_recommendation`
--

INSERT INTO `series_recommendation` (`id`, `title`, `content`, `genre`, `pic_url`) VALUES
(1, 'A nagy pénz rablás', 'A nagy pénzrablás  egy izgalmas és fordulatos spanyol sorozat, amelyben egy rejtélyes \"Professzor\" egy zseniális tervet eszel ki: a világ legnagyobb rablását. Nyolc különleges képességű bűnözőt toboroz, hogy betörjenek a Spanyol Királyi Pénzverdébe és ott nyomtassanak milliókat.A sorozat tele van feszültséggel, érzelmi drámával és váratlan fordulatokkal, miközben a rablók és a túszok közötti dinamikát, valamint a hatóságokkal való macska-egér játékot ismerhetjük meg.A történet középpontjában nemcsak az akció, hanem a szereplők személyes történetei és kapcsolatai állnak.', 'bűnügyi drámasorozat', 'lacasadepapel.jpg'),
(2, 'Chernobyl', 'Csernobil egy megrázó és hiteles minisorozat, amely a történelem egyik legsúlyosabb nukleáris katasztrófáját mutatja be.A sorozat a csernobili atomerőmű 1986-os robbanását, annak következményeit és a katasztrófa kezelésére tett emberfeletti erőfeszítéseket tárja fel.Lenyűgöző részletességgel és mély érzelmekkel mutatja be a tudományos tévedéseket, a politikai hazugságokat és az emberi áldozatokat, amelyek az események hátterében álltak.A sorozat egyszerre tanulságos és megrendítő, kiemelve a bátorságot és az igazságért való harc fontosságát.', 'történelmi dráma', 'csernobil.jpg'),
(3, 'Rick és Morty', 'Rick és Morty egy groteszk show, amely Rick, egy zsémbes, alkoholista tudós és unokája, Morty kalandjait követi, miközben különböző dimenziókba és világokba utaznak.A sorozat ötvözi az abszurd humort a mély filozófiai kérdésekkel, miközben sokszor éles társadalomkritikát is megfogalmaz.A karakterek és történetek gyakran határvonalon egyensúlyoznak a nevetséges és a drámai között, így nemcsak szórakoztató, hanem elgondolkodtató is, felforgató világot teremt, amelyben a tudomány,  és a lét kérdései keverednek, miközben minden epizód egy új, elképesztő és gyakran abszurd kalandot hoz.', 'animált szitkom sci-fi', 'rickandmorty.jpg'),
(4, 'Squid Game (2. évad)', 'A Nyerd meg az életed, Netflix 2021-ben bemutatott, thriller műfajú saját gyártású koreai televíziós sorozata, melyet Hvang Donghjok írt és rendezett. A történet egy túlélőjátékról szól, melyben 456, súlyos anyagi helyzetben lévő játékosnak koreai gyerekjátékokat kell játszaniuk a több milliós nyeremény reményében, azonban a vesztesek nem egyszerűen kiesnek, hanem meghalnak.Hvang a történettel, a dél-koreai társadalom osztályegyenlőtlenségeit mutatja be.', 'thrillersorozat', 'squidgame.jpg'),
(5, 'Fallout', 'A Fallout sorozat a nukleáris háború utáni Los Angelesben játszódik, ahol a túlélők földalatti bunkerekben élnek, hogy megvédjék magukat a sugárzástól, mutánsoktól és banditáktól.  sci-fi western elemekkel, melyet Geneva Robertson-Dworet és Graham Wagner készített az Amazon Prime Video számára.\r\n A sorozat világa és cselekménye az Interplay Entertainment által kitalált, jelenleg a Bethesda Softworks tulajdonát képező Fallout videojáték-franchise-on alapul.', 'dráma posztapokaliptikus sci-fi', 'fallout.jpg'),
(6, 'Pingvin', 'A Pingvin (eredeti cím: The Penguin) 2024-es amerikai bűnügyi drámasorozat, amelyet Lauren LeFranc alkotott, A 2022-es Batman világában játszódik. A főbb szerepekben Colin Farrell, Cristin Milioti, Rhenzy Feliz, Deirdre O’Connell és Clancy Brown látható.', 'bűnügyi sorozat, dráma', 'pingvin.jpg'),
(7, 'Szégyentelenek', 'A Szégyentelenek (angolul Shameless) egy népszerű amerikai tévésorozat, amelyet Paul Abbott brit sorozata alapján készítettek. A történet középpontjában a Gallagher család áll, akik a Chicago egyik szegényes negyedében élnek. A család feje, Frank Gallagher, egy alkoholista, aki képtelen gondoskodni saját gyermekeiről, így a gyerekeknek kell felnőniük és magukról gondoskodniuk. A sorozat humora sötét, gyakran tabukat döntöget, miközben komoly társadalmi kérdéseket is érint, mint például a családi dinamika, a szegénység, a drogproblémák és az erkölcsi dilemmák.', 'Dráma Vígjáték', 'shameless.jpg'),
(8, 'Totál Szívás', 'A totál szívás amelyet Vince Gilligan alkotott. A történet középpontjában Walter White (Bryan Cranston), egy középiskolai kémiatanár áll, aki rákos diagnózist kap, és úgy dönt, hogy metanfetamin készítésébe kezd, hogy biztosítsa családja jövőjét. A sorozat bemutatja, hogyan válik Walter White fokozatosan a törvényen kívüli bűnözővé, miközben egyre mélyebbre süllyed a drogkereskedelem világába, és elveszíti erkölcsi iránytűjét.A Breaking Bad egyedülálló módon ötvözi a drámát, a feszültséget és a karakterfejlődést. Walter White karakterének változása az egyik legemlékezetesebb elem, ahogy a kezdetben ártatlan férfi egy manipuláló, hataloméhes figurává válik. A sorozat másik kiemelkedő karaktere Jesse Pinkman (Aaron Paul), Walter korábbi diákja és bűntársa, aki az ő útján próbál boldogulni.', 'bűnügyi drámasorozat', 'saymyname.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `permission` int(2) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `permission`, `username`, `email`, `password`) VALUES
(1, 2, 'admin1', 'admin@gmail.com', '$2b$10$VJrwQkmDk4QKbyLVGnsxbOrT5WtBoGl5W/d/mwQmb50/nvFSEhcda'),
(2, 2, 'user', 'user@gmail.com', '$2b$10$YZMjUs6iHzw8llyr0TKRSu.Dnyu2IrSEQlGFfDczOxLVoRDELcfy6');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `film_diary`
--
ALTER TABLE `film_diary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- A tábla indexei `film_likes`
--
ALTER TABLE `film_likes`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `film_recommendation`
--
ALTER TABLE `film_recommendation`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `series_likes`
--
ALTER TABLE `series_likes`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `series_recommendation`
--
ALTER TABLE `series_recommendation`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `film_diary`
--
ALTER TABLE `film_diary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `film_likes`
--
ALTER TABLE `film_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `film_recommendation`
--
ALTER TABLE `film_recommendation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `series_likes`
--
ALTER TABLE `series_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `series_recommendation`
--
ALTER TABLE `series_recommendation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
